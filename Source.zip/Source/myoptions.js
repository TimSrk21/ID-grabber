window.onload = (event) => {
	window.location.replace("https://app.studytogether.com/study-stats");
};


